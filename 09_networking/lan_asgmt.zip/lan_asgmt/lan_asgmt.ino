#include <WiFi.h>
#include <WiFiAP.h>
#include <WiFiClient.h>
#include <WiFiGeneric.h>
#include <WiFiMulti.h>
#include <WiFiSTA.h>
#include <WiFiScan.h>
#include <WiFiServer.h>
#include <WiFiType.h>
#include <WiFiUdp.h>
#include "pitches.h"


/*
 WiFi Web Server LED Blink

 A simple web server that lets you blink an LED via the web.
 This sketch will print the IP address of your WiFi Shield (once connected)
 to the Serial monitor. From there, you can open that address in a web browser
 to turn on and off the LED on pin 5.

 If the IP address of your shield is yourAddress:
 http://yourAddress/H turns the LED on
 http://yourAddress/L turns it off

 This example is written for a network using WPA2 encryption. For insecure
 WEP or WPA, change the Wifi.begin() call and use Wifi.setMinSecurity() accordingly.

 Circuit:
 * WiFi shield attached
 * LED attached to pin 5

 created for arduino 25 Nov 2012
 by Tom Igoe

ported for sparkfun esp32
31.01.2017 by Jan Hendrik Berlin

 */
// end of beginning is the upbeat song
int BUZZER_PIN = 5;
int melody1[] = {
  REST,
  
  NOTE_D5, NOTE_D5, NOTE_E5, NOTE_FS5, NOTE_G5, NOTE_A5, NOTE_E5, NOTE_D5, NOTE_FS5, NOTE_E5, NOTE_D5, REST,
  NOTE_B5, NOTE_D5, NOTE_D5, NOTE_D5, NOTE_CS5, NOTE_B5, NOTE_A5, NOTE_B5, NOTE_CS5, NOTE_D5, NOTE_B5, NOTE_A5,
  NOTE_D5, NOTE_D5, NOTE_E5, NOTE_FS5, NOTE_G5, NOTE_A5, NOTE_E5, NOTE_D5, NOTE_FS5, NOTE_E5, NOTE_D5,
  NOTE_A5, NOTE_D5, REST, NOTE_A5, NOTE_D5, REST, NOTE_A5, NOTE_D5, REST, NOTE_A5, NOTE_D5, NOTE_B5,
  NOTE_CS5, NOTE_CS5, NOTE_CS5, NOTE_CS5, NOTE_CS5,
  NOTE_A5, NOTE_CS5, NOTE_A5, NOTE_CS5, NOTE_A5, NOTE_CS5,
  NOTE_D5, NOTE_D5, REST,
  NOTE_CS5, NOTE_CS5, NOTE_CS5,
  NOTE_D5, NOTE_CS5, NOTE_D5, NOTE_CS5, NOTE_D5, NOTE_FS5,
  NOTE_D5, NOTE_CS5, NOTE_D5, NOTE_CS5, NOTE_D5, NOTE_CS5,
  NOTE_CS5, NOTE_D5, NOTE_CS5, NOTE_D5, NOTE_CS5, NOTE_CS5,
  NOTE_D5, NOTE_CS5, NOTE_CS5, NOTE_D5, NOTE_CS5, NOTE_CS5,
  NOTE_CS5, NOTE_D5, NOTE_CS5, NOTE_CS5, NOTE_G5, NOTE_FS5,
  NOTE_D5, NOTE_E5, NOTE_E5, NOTE_E5, NOTE_D5,

  REST
};

// note durations: 4 = quarter note, 8 = eighth note, etc.: song: End of Beginning 
int durations1[] = {4,

  4, 4, 4, 4, 4, 4, 2, 4, 4, 4, 1, 4,
  4, 4, 4, 4, 4, 4, 2, 4, 4, 4, 1, 2,
  4, 4, 4, 4, 4, 4, 2, 4, 4, 4, 4,
  4, 2, 4, 4, 2, 4, 4, 2, 4, 4, 4, 2,
  4, 4, 4, 4, 4,
  4, 4, 4, 4, 4, 4,
  4, 2, 2,
  4, 4, 4,
  4, 4, 4, 4, 4, 4,
  4, 4, 4, 4, 4, 4,
  4, 4, 4, 4, 4, 4,
  4, 4, 4, 4, 4, 4,
  4, 4, 4, 4, 4, 4,
  4, 4, 4, 4, 4,

  1};
// song 2 is Die with A smile

int melody2[] = {
 NOTE_FS4, NOTE_FS4, NOTE_A4,
  NOTE_FS4, NOTE_A4,
  NOTE_FS4, NOTE_GS4, NOTE_GS4, NOTE_GS4, NOTE_A4, NOTE_B4,

  NOTE_E4, NOTE_GS4,
  NOTE_CS5, NOTE_GS4, NOTE_FS4,

  NOTE_FS4, NOTE_FS4, NOTE_A4,
  NOTE_FS4, NOTE_FS4, NOTE_A4,
  NOTE_FS4, NOTE_E4, NOTE_GS4, NOTE_GS4, NOTE_GS4, NOTE_A4, NOTE_B4,

  NOTE_E4, NOTE_GS4,
  NOTE_CS5, NOTE_GS4, NOTE_FS4,};
int durations2[] = {4, 4, 3, 4, 3, 4, 3, 8, 8, 4, 3, 4, 1, 4, 4, 1, 4, 4, 3, 4, 4, 3, 4, 3, 3, 8, 8, 4, 3, 4, 1, 4, 4, 1,};

int melody3[] = {
 REST,

  NOTE_E4, NOTE_DS4, NOTE_B3, NOTE_E4, NOTE_DS4, NOTE_B3,
  NOTE_E4, NOTE_DS4, NOTE_B3, NOTE_E4, NOTE_FS4, NOTE_GS4,
  NOTE_B4, NOTE_CS5, NOTE_E5, NOTE_A5, NOTE_GS5, NOTE_FS5,
  NOTE_D5, NOTE_D5, NOTE_E5, NOTE_FS5, NOTE_E5,
  NOTE_B4, NOTE_GS4, NOTE_A5, NOTE_B4,
  NOTE_DS5, NOTE_E5,
  NOTE_B4, NOTE_CS5, NOTE_E5, NOTE_A5, NOTE_GS5,
  NOTE_DS5,
  NOTE_B5, NOTE_A5, NOTE_GS5,

  NOTE_E5, NOTE_E5, NOTE_E5, NOTE_FS5, NOTE_FS5, NOTE_FS5,
  NOTE_GS5, NOTE_GS5, NOTE_GS5, NOTE_DS5, NOTE_DS5, NOTE_DS5,

  NOTE_CS5, NOTE_E4, NOTE_CS5, NOTE_B4,
  NOTE_CS5, NOTE_B4, NOTE_GS4, NOTE_A4,
  NOTE_B4, NOTE_A4, NOTE_GS4, NOTE_E4,
  NOTE_E4
};

int durations3[] = {
  4,

  4, 4, 4, 4, 4, 4,
  4, 4, 4, 4, 4, 4,
  4, 4, 4, 4, 4, 4,
  2, 4, 4, 4, 4,
  2, 4, 4, 4,
  2, 2,
  4, 4, 4, 4, 4,
  2,
  4, 4, 4,

  4, 4, 4, 4, 4, 4,
  4, 4, 4, 4, 4, 4,

  2, 4, 2, 4,
  2, 2, 4, 4,
  2, 2, 4, 4,
  1,
};
const char *ssid = "MAKERSPACE";
const char *password = "12345678";

NetworkServer server(80);

void setup() {
  Serial.begin(115200);
  pinMode(5, OUTPUT);  // set the LED pin mode

  delay(10);

  // We start by connecting to a WiFi network

  Serial.println();
  Serial.println();
  Serial.print("Connecting to ");
  Serial.println(ssid);

  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("");
  Serial.println("WiFi connected.");
  Serial.println("IP address: ");
  Serial.println(WiFi.localIP());

  server.begin();
}

void loop() {
  NetworkClient client = server.accept();  // listen for incoming clients

  if (client) {                     // if you get a client,
    Serial.println("New Client.");  // print a message out the serial port
    String currentLine = "";        // make a String to hold incoming data from the client
    while (client.connected()) {    // loop while the client's connected
      if (client.available()) {     // if there's bytes to read from the client,
        char c = client.read();     // read a byte, then
        Serial.write(c);            // print it out the serial monitor
        if (c == '\n') {            // if the byte is a newline character

          // if the current line is blank, you got two newline characters in a row.
          // that's the end of the client HTTP request, so send a response:
          if (currentLine.length() == 0) {
            // HTTP headers always start with a response code (e.g. HTTP/1.1 200 OK)
            // and a content-type so the client knows what's coming, then a blank line:
            client.println("HTTP/1.1 200 OK");
            client.println("Content-type:text/html");
            client.println();

            // the content of the HTTP response follows the header:
            client.print("Click <a href=\"/H\">here</a> If you want an upbeat song.<br>");
            client.print("Click <a href=\"/L\">here</a> If you want a calm song.<br>");
            client.print("Click <a href=\"/N\">here</a> If you want a lowbeat song.<br>");

            // The HTTP response ends with another blank line:
            client.println();
            // break out of the while loop:
            break;
          } else {  // if you got a newline, then clear currentLine:
            currentLine = "";
          }
        } else if (c != '\r') {  // if you got anything else but a carriage return character,
          currentLine += c;      // add it to the end of the currentLine
        }

        // Check to see if the client request was "GET /H" or "GET /L" or "GET /N":
        if (currentLine.endsWith("GET /H")) {
            // GET /H turns the LED on
            int size = sizeof(durations1) / sizeof(int);

            for (int note = 0; note < size; note++) {
              //to calculate the note duration, take one second divided by the note type.
              //e.g. quarter note = 1000 / 4, eighth note = 1000/8, etc.
              if (currentLine.endsWith("GET /N") || currentLine.endsWith("GET /L"))
              {
                Serial.println(currentLine);
                noTone(BUZZER_PIN);
                break;
              } else{
                int duration = 1000 / durations1[note];
                tone(BUZZER_PIN, melody1[note], duration);

                //to distinguish the notes, set a minimum time between them.
                //the note's duration + 30% seems to work well:
                int pauseBetweenNotes = duration * 1.30;
                delay(pauseBetweenNotes);

                //stop the tone playing:
                noTone(BUZZER_PIN);
              }
            }

        }
        if (currentLine.endsWith("GET /L")) {
          int size = sizeof(durations2) / sizeof(int);
          for (int note = 0; note < size; note++) { 
            int duration = 1000 / durations2[note];
            tone(5, melody2[note], duration);
            int pauseBetweenNotes = duration * 1.30;
            delay(pauseBetweenNotes);
            noTone(BUZZER_PIN);
          }
        }
        if (currentLine.endsWith("GET /N")) {
          int size = sizeof(durations3) / sizeof(int);
          for (int note = 0; note < size; note++) {
          int duration = 1000 / durations3[note];
          tone(BUZZER_PIN, melody3[note], duration);
          int pauseBetweenNotes = duration * 1.30;
          delay(pauseBetweenNotes);
          noTone(BUZZER_PIN);
          }   
        }
      }
    }
    // close the connection:
    client.stop();
    Serial.println("Client Disconnected.");
  }
}

