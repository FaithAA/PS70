#include <WiFi.h>
#include <WiFiAP.h>
#include <WiFiClient.h>
#include <WiFiGeneric.h>
#include <WiFiMulti.h>
#include <WiFiSTA.h>
#include <WiFiScan.h>
#include <WiFiServer.h>
#include <WiFiType.h>
#include <WiFiUdp.h>
#include <ESP32Servo.h>
#include "pitches.h"  

//wifi
const char* ssid     = "MAKERSPACE";
const char* password = "12345678";

// pins
const int SERVO_PIN  = 22;   // 9g servo
const int BUZZER_PIN = 23; 

Servo myServo;

// SONG ARRAYS
int melody[] = {
  NOTE_CS4, NOTE_E4, NOTE_CS4, NOTE_CS4, NOTE_E4,
  NOTE_CS4, NOTE_CS4, NOTE_E4, NOTE_CS4, NOTE_DS4,
  NOTE_CS4, NOTE_CS4, NOTE_E4, NOTE_CS4,
  NOTE_B3,
  NOTE_CS4, NOTE_E4, NOTE_CS4, NOTE_CS4, NOTE_E4,
  NOTE_CS4, NOTE_DS4, NOTE_CS4, NOTE_E4,
  NOTE_B3,
  NOTE_E4, NOTE_E4, NOTE_E4, NOTE_E4, NOTE_E4, NOTE_E4, NOTE_E4, NOTE_E4, NOTE_E4,
  NOTE_E4, NOTE_E4, NOTE_E4, NOTE_E4, NOTE_FS4, NOTE_GS4, NOTE_GS4,
  NOTE_GS4, NOTE_E4, NOTE_FS4, NOTE_B4, NOTE_GS4, NOTE_GS4, NOTE_GS4, NOTE_GS4, NOTE_GS4,
  NOTE_FS4, NOTE_FS4, NOTE_FS4, NOTE_GS4, NOTE_FS4, NOTE_FS4, NOTE_FS4, NOTE_FS4, NOTE_FS4, NOTE_GS4, NOTE_FS4,
  NOTE_E4, NOTE_CS4, NOTE_CS4, NOTE_GS4, NOTE_GS4,
  NOTE_GS4, NOTE_GS4, NOTE_GS4, NOTE_GS4, NOTE_GS4, NOTE_GS4, NOTE_GS4, NOTE_GS4, NOTE_GS4,
  NOTE_GS4, NOTE_B4, NOTE_GS4, NOTE_GS4, NOTE_FS4, NOTE_FS4, NOTE_E4, NOTE_GS4,
  NOTE_FS4, NOTE_E4, NOTE_E4, NOTE_E4, NOTE_B4, NOTE_GS4, NOTE_GS4, NOTE_GS4, NOTE_FS4,
  NOTE_FS4, NOTE_FS4, NOTE_FS4, NOTE_FS4, NOTE_FS4, NOTE_FS4, NOTE_FS4, NOTE_FS4,
  NOTE_E4, NOTE_CS4, NOTE_CS4, NOTE_CS4, NOTE_CS4, NOTE_CS4,
  NOTE_GS3, NOTE_B3,
  NOTE_CS4, NOTE_CS4, NOTE_FS4, NOTE_GS4, NOTE_E4, NOTE_FS4,
  NOTE_B3,
  NOTE_E4, NOTE_FS4, NOTE_GS4, NOTE_FS4, NOTE_E4, NOTE_CS4, NOTE_E4, NOTE_GS4,
  NOTE_FS4, NOTE_E4, NOTE_FS4, NOTE_CS4, NOTE_B4, NOTE_GS4, NOTE_GS4, NOTE_FS4, NOTE_FS4,
  NOTE_E4, NOTE_CS4, NOTE_E4, NOTE_FS4, NOTE_GS4, NOTE_FS4, NOTE_E4,
  NOTE_FS4, NOTE_E4, NOTE_CS4, NOTE_CS4,
  NOTE_B3,
  NOTE_CS4, NOTE_CS4, NOTE_FS4, NOTE_GS4, NOTE_E4, NOTE_FS4, NOTE_FS4,
  NOTE_B3,
  NOTE_FS4, NOTE_GS4, NOTE_FS4, NOTE_E4, NOTE_CS4, NOTE_E4, NOTE_GS4, NOTE_FS4,
  NOTE_E4, NOTE_FS4, NOTE_CS4, NOTE_B4, NOTE_GS4, NOTE_GS4, NOTE_FS4, NOTE_FS4, NOTE_E4,
  NOTE_CS4, NOTE_B4, NOTE_GS4, NOTE_GS4, NOTE_FS4, NOTE_FS4, NOTE_E4,
  NOTE_CS4, NOTE_CS4,
  NOTE_GS3, NOTE_B3,
  NOTE_E4, NOTE_FS4, NOTE_GS4, NOTE_FS4, NOTE_E4, NOTE_E4, NOTE_E4, NOTE_FS4, NOTE_FS4,
  NOTE_E4, NOTE_FS4, NOTE_GS4, NOTE_FS4, NOTE_E4, NOTE_E4, NOTE_E4, NOTE_FS4,
  NOTE_CS4, NOTE_E4, NOTE_FS4, NOTE_GS4, NOTE_CS4,
  NOTE_E4, NOTE_E4, NOTE_FS4, NOTE_FS4, NOTE_E4, NOTE_FS4, NOTE_GS4,
  NOTE_FS4, NOTE_E4, NOTE_E4, NOTE_FS4, NOTE_CS4, NOTE_CS4,
  NOTE_FS4, NOTE_GS4, NOTE_B4, NOTE_GS4, NOTE_FS4, NOTE_E4, NOTE_E4, NOTE_FS4,
  NOTE_E4, NOTE_FS4, NOTE_GS4, NOTE_FS4, NOTE_E4, NOTE_E4, NOTE_FS4,
  NOTE_CS4, NOTE_CS4, NOTE_CS4, NOTE_CS4, NOTE_CS4, NOTE_E4, NOTE_FS4, NOTE_GS4, NOTE_CS4, NOTE_E4,
  NOTE_FS4, NOTE_E4, NOTE_FS4, NOTE_E4, NOTE_FS4, NOTE_GS4,
  NOTE_FS4, NOTE_E4, NOTE_E4, NOTE_FS4, NOTE_CS4, NOTE_CS4, NOTE_CS4, NOTE_E4, NOTE_E4,
  NOTE_FS4, NOTE_FS4, NOTE_GS4, NOTE_GS4,
  NOTE_E4, NOTE_FS4, NOTE_GS4, NOTE_FS4, NOTE_E4, NOTE_E4, NOTE_FS4, NOTE_CS4, NOTE_CS4,
  NOTE_CS4, NOTE_E4, NOTE_E4, NOTE_FS4, NOTE_FS4, NOTE_GS4,
  NOTE_GS4, NOTE_E4, NOTE_FS4, NOTE_GS4, NOTE_FS4,
  NOTE_E4, NOTE_E4, NOTE_FS4, NOTE_CS4, NOTE_CS4, NOTE_CS4, NOTE_E4, NOTE_E4,
  NOTE_FS4, NOTE_FS4, NOTE_GS4, NOTE_GS4,
  NOTE_E4, NOTE_FS4, NOTE_GS4, NOTE_FS4, NOTE_E4, NOTE_E4, NOTE_FS4, NOTE_CS4, NOTE_CS4,
  NOTE_CS4, NOTE_CS4, NOTE_CS4, NOTE_CS4, NOTE_E4, NOTE_FS4, NOTE_GS4, NOTE_CS4, NOTE_E4, NOTE_FS4,
  NOTE_CS4,
};

int durations[] = {
  2,2,4,2,2,4,2,2,4,2,2,2,2,2,2,2,2,4,2,2,4,2,2,2,2,8,8,4,4,8,8,8,8,8,8,8,2,8,8,4,2,8,8,4,8,8,8,4,4,8,8,8,8,8,4,8,4,8,8,8,8,4,2,8,8,8,8,4,8,8,8,8,8,8,2,8,4,8,8,8,8,8,2,4,8,8,2,4,8,8,8,8,8,8,2,8,8,4,4,4,8,8,2,4,4,2,4,2,2,4,8,8,8,2,2,8,4,8,4,4,4,4,8,8,8,8,2,8,8,4,8,8,4,2,8,4,8,4,4,4,4,2,2,2,2,4,8,8,8,2,2,2,4,8,4,4,4,4,8,8,8,8,2,8,8,4,8,8,4,2,8,8,4,8,8,4,2,2,4,2,8,8,4,8,8,4,8,8,2,8,8,4,8,8,4,8,8,2,8,8,4,4,4,8,8,2,8,8,4,8,8,8,4,8,2,4,4,8,8,4,4,8,2,8,8,4,4,4,8,8,4,8,8,8,8,8,8,4,4,4,4,8,2,8,8,4,8,8,8,4,8,4,4,4,4,4,4,4,2,8,8,4,8,8,8,4,8,4,4,4,4,4,4,4,2,8,8,4,8,8,8,4,8,4,4,4,4,4,4,4,2,8,8,4,8,8,8,4,8,4,8,8,8,8,8,8,4,4,4,4,2
};

const int numNotes1 = sizeof(melody) / sizeof(melody[0]);

// swing limits for the hands
const int ANGLE_LEFT   = 45;
const int ANGLE_RIGHT  = 105;
const int ANGLE_CENTER = 80;

int servoPos  = ANGLE_CENTER;
int servoDir  = 1;     // +1 or -1 (sweeping direction)
int servoMode = 0;     // 0 = off, 1 = slow, 2 = fast

unsigned long startTime = 0;
const unsigned long runDuration = 30000;   // 30 seconds

// SPEED tuning
unsigned long lastServoStep = 0;

// FAST = push servo to physical maximum speed
const unsigned long fastInterval = 3;   // ms between updates
const int fastStep = 5;                 // degrees per update

// half speed
const unsigned long slowInterval = 12;  // slower updates
const int slowStep = 3;

// Web Server
WiFiServer server(80);

//SONG: buzzer + servo, one move per note
void playSongWithServo() {
  servoMode = 0;               // stop normal sweep
  int dir = 1;                 // start by going right

  for (int note = 0; note < numNotes1; note++) {
    int noteSymbol = durations[note];
    int duration = 1000 / noteSymbol;  // ms for this note

    // decide which side for this note
    int targetAngle = (dir > 0) ? ANGLE_RIGHT : ANGLE_LEFT;
    dir = -dir;  // flip for next note

    // move servo to that side
    myServo.write(targetAngle);

    // play the note
    int freq = melody[note];
    if (freq > 0) {
      tone(BUZZER_PIN, freq, duration);
    }

    // hold pose for note duration + small gap
    int pauseBetweenNotes = duration * 1.30;
    delay(pauseBetweenNotes);

    noTone(BUZZER_PIN);
  }

  // after the song, return to center
  myServo.write(ANGLE_CENTER);
}

//  Update servo movement (FAST/SLOW modes)
void updateServo() {
  if (servoMode == 0) {
    return;   // servo stopped
  }

  // Stop after runDuration
  if (millis() - startTime >= runDuration) {
    servoMode = 0;
    myServo.write(ANGLE_CENTER); // center when done
    return;
  }

  unsigned long now = millis();

  unsigned long interval;
  int step;

  // Select speed mode
  if (servoMode == 1) {       // SLOW
    interval = slowInterval;
    step = slowStep;
  } else {                    // FAST (servoMode == 2)
    interval = fastInterval;
    step = fastStep;
  }

  if (now - lastServoStep >= interval) {
    lastServoStep = now;

    // Move servo
    servoPos += servoDir * step;

    // Limit sweep between 45° and 105°
    if (servoPos > ANGLE_RIGHT) {
      servoPos = ANGLE_RIGHT;
      servoDir = -1;
    }
    if (servoPos < ANGLE_LEFT) {
      servoPos = ANGLE_LEFT;
      servoDir = 1;
    }

    myServo.write(servoPos);
  }
}

void setup() {
  Serial.begin(115200);

  myServo.attach(SERVO_PIN, 500, 2400);  // micro servo range
  myServo.write(servoPos);

  pinMode(BUZZER_PIN, OUTPUT);

  // Connect to WiFi
  Serial.print("Connecting to ");
  Serial.println(ssid);

  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nWiFi connected.");
  Serial.println("IP address:");
  Serial.println(WiFi.localIP());

  server.begin();
}

void loop() {
  updateServo();   // FAST/SLOW modes

  WiFiClient client = server.available();   // for WiFiServer on ESP32
  if (!client) return;

  Serial.println("New Client.");
  String currentLine = "";

  while (client.connected()) {
    if (client.available()) {
      char c = client.read();
      Serial.write(c);

      if (c == '\n') {
        if (currentLine.length() == 0) {
          // send webpage
          client.println("HTTP/1.1 200 OK");
          client.println("Content-type:text/html");
          client.println();

          client.print("<a href=\"/H\">FAST (high BPM)</a><br>");
          client.print("<a href=\"/L\">SLOW (low BPM)</a><br>");
          client.print("<a href=\"/S\">Dance To Song (Shape of You)</a><br>");

          client.println();
          break;
        } else {
          currentLine = "";
        }
      } 
      else if (c != '\r') {
        currentLine += c;
      }

      //handle commands
      if (currentLine.endsWith("GET /H")) {
        servoMode = 2;          // FAST
        startTime = millis();
        Serial.println("FAST mode started (30 seconds)");
      }

      if (currentLine.endsWith("GET /L")) {
        servoMode = 1;          // SLOW
        startTime = millis();
        Serial.println("SLOW mode started (30 seconds)");
      }

      if (currentLine.endsWith("GET /S")) {
        Serial.println("Dancing to Shape Of You");
        playSongWithServo();    // blocks until song done
      }
    }

    updateServo();  // also update while client is connected (for H/L)
  }

  client.stop();
  Serial.println("Client Disconnected.");
}
